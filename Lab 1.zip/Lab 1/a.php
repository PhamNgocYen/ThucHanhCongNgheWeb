<?php
    // echo "Hello xin chào tất cả mọi người";
    $name = "Nguyễn Văn Vĩnh Nguyên";
    echo "Hello xin chào tất cả mọi người, tôi tên là ".$name;

?>