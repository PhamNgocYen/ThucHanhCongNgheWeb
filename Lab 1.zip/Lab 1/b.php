<?php
    include 'a.php';
    echo '<br/>';
    echo 'Hôm nay tôi buồn một mình trên phố đông.';
    echo '<br/>';
    echo 'Nơi ánh đèn soi sáng long lanh';
?>