<?php
$config['host'] = 'localhost';
$config['user'] = 'root';
$config['pass'] = '';
$config['data'] = 'tintuc';
?>