<?php
$config = mysqli_connect("localhost", "root", "", "review");
// nếu có lỗi sảy ra thì dừng đoạn mẫ và in ra thông báo lỗi
if(mysqli_connect_errno()!==0)
{
    die("Error: Could not connect to the database. An error".mysqli_connect_errno()." ocurred.");
}

mysqli_set_charset($config,'utf8');

?>
