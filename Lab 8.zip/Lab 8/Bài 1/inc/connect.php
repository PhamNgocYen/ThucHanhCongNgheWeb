<?php
    $DATABASE = "udn";
    $SERVER = 'localhost';
    $USER = 'root';
    $PASS = '';

    $conn = mysqli_connect($SERVER, $USER, $PASS, $DATABASE);

    
?>